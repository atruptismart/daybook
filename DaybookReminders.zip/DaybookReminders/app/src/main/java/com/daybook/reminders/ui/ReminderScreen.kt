package com.daybook.reminders.ui

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.daybook.reminders.data.Reminder
import com.daybook.reminders.data.RepeatMode
import java.text.SimpleDateFormat
import java.util.*

private val Teal = Color(0xFF2F6F62)
private val TealSoft = Color(0xFFE4EFEA)
private val Amber = Color(0xFFC8862A)
private val Ink = Color(0xFF1B1E2B)
private val InkSoft = Color(0xFF5B6070)
private val Paper = Color(0xFFF3F4EE)
private val Danger = Color(0xFFB14B3D)
private val Rule = Color(0xFFDADCD2)

@Composable
fun ReminderScreen(viewModel: ReminderViewModel = viewModel()) {
    val reminders by viewModel.reminders.collectAsState()
    var showAddSheet by remember { mutableStateOf(false) }

    Scaffold(
        containerColor = Paper,
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddSheet = true },
                containerColor = Teal,
                contentColor = Color.White,
                shape = CircleShape
            ) { Icon(Icons.Filled.Add, contentDescription = "Add reminder") }
        }
    ) { padding ->
        Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
            Spacer(Modifier.height(18.dp))
            Text(
                text = SimpleDateFormat("EEEE, MMMM d", Locale.getDefault()).format(Date()),
                color = InkSoft,
                fontSize = 13.sp
            )
            Text(
                text = "Daybook",
                color = Ink,
                fontSize = 32.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(16.dp))

            if (reminders.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text(
                        "Nothing on the page yet.\nTap + to write in your first reminder.",
                        color = InkSoft,
                        fontSize = 14.sp
                    )
                }
            } else {
                val now = System.currentTimeMillis()
                val grouped = reminders.sortedBy { it.dateTimeMillis }.groupBy { r ->
                    groupFor(r, now)
                }
                LazyColumn {
                    listOf("Overdue", "Today", "Tomorrow", "Upcoming").forEach { label ->
                        val items = grouped[label] ?: return@forEach
                        item {
                            Row(
                                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    label,
                                    color = if (label == "Overdue") Danger else InkSoft,
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 13.sp
                                )
                                Text("${items.size}", color = InkSoft, fontSize = 13.sp)
                            }
                            Divider(color = Rule)
                        }
                        items(items) { reminder ->
                            ReminderRow(
                                reminder = reminder,
                                onToggle = { viewModel.toggleDone(reminder) },
                                onDelete = { viewModel.delete(reminder) }
                            )
                        }
                    }
                    item { Spacer(Modifier.height(90.dp)) }
                }
            }
        }
    }

    if (showAddSheet) {
        AddReminderSheet(
            onDismiss = { showAddSheet = false },
            onSave = { title, millis, repeat ->
                viewModel.addReminder(title, millis, repeat)
                showAddSheet = false
            }
        )
    }
}

private fun groupFor(r: Reminder, now: Long): String {
    val cal = Calendar.getInstance()
    val today = cal.clone() as Calendar
    val tomorrow = (cal.clone() as Calendar).apply { add(Calendar.DAY_OF_YEAR, 1) }
    val rCal = Calendar.getInstance().apply { timeInMillis = r.dateTimeMillis }

    fun sameDay(a: Calendar, b: Calendar) =
        a.get(Calendar.YEAR) == b.get(Calendar.YEAR) && a.get(Calendar.DAY_OF_YEAR) == b.get(Calendar.DAY_OF_YEAR)

    return when {
        !r.done && r.dateTimeMillis < now -> "Overdue"
        sameDay(rCal, today) -> "Today"
        sameDay(rCal, tomorrow) -> "Tomorrow"
        else -> "Upcoming"
    }
}

@Composable
private fun ReminderRow(reminder: Reminder, onToggle: () -> Unit, onDelete: () -> Unit) {
    val cal = Calendar.getInstance().apply { timeInMillis = reminder.dateTimeMillis }
    val timeStr = SimpleDateFormat("h:mm a", Locale.getDefault()).format(cal.time)
    val dateStr = SimpleDateFormat("MMM d", Locale.getDefault()).format(cal.time)

    Row(
        Modifier.fillMaxWidth().padding(vertical = 12.dp),
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            Modifier
                .size(26.dp)
                .background(if (reminder.done) Teal else Color.Transparent, CircleShape)
                .then(
                    if (!reminder.done) Modifier.background(Color.White, CircleShape) else Modifier
                )
                .clickable { onToggle() },
            contentAlignment = Alignment.Center
        ) {
            if (reminder.done) {
                Icon(Icons.Filled.Check, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
            }
        }

        Column(Modifier.width(56.dp)) {
            Text(timeStr, fontSize = 15.sp, fontWeight = FontWeight.Medium, color = if (reminder.done) InkSoft else Ink)
        }

        Column(Modifier.weight(1f)) {
            Text(
                reminder.title,
                fontSize = 16.sp,
                color = if (reminder.done) InkSoft else Ink,
                textDecoration = if (reminder.done) TextDecoration.LineThrough else null
            )
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(dateStr, fontSize = 12.5.sp, color = InkSoft)
                if (reminder.repeat != RepeatMode.NONE) {
                    Box(
                        Modifier
                            .background(TealSoft, RoundedCornerShape(100))
                            .padding(horizontal = 7.dp, vertical = 1.dp)
                    ) {
                        Text(
                            if (reminder.repeat == RepeatMode.DAILY) "Daily" else "Weekly",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = Teal
                        )
                    }
                }
            }
        }

        IconButton(onClick = onDelete, modifier = Modifier.size(28.dp)) {
            Icon(Icons.Filled.Delete, contentDescription = "Delete", tint = InkSoft, modifier = Modifier.size(18.dp))
        }
    }
    Divider(color = Rule)
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AddReminderSheet(
    onDismiss: () -> Unit,
    onSave: (String, Long, RepeatMode) -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var title by remember { mutableStateOf("") }
    var repeat by remember { mutableStateOf(RepeatMode.NONE) }

    val defaultCal = remember {
        Calendar.getInstance().apply {
            add(Calendar.MINUTE, 30 - (get(Calendar.MINUTE) % 5))
        }
    }
    var selectedCal by remember { mutableStateOf(defaultCal) }

    ModalBottomSheet(onDismissRequest = onDismiss, containerColor = Color.White) {
        Column(Modifier.padding(20.dp).padding(bottom = 24.dp)) {
            Text("New reminder", fontSize = 20.sp, fontWeight = FontWeight.SemiBold, color = Ink)
            Spacer(Modifier.height(16.dp))

            OutlinedTextField(
                value = title,
                onValueChange = { title = it },
                label = { Text("What's it about") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(12.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = {
                    DatePickerDialog(
                        context,
                        { _, y, m, d ->
                            val c = selectedCal.clone() as Calendar
                            c.set(Calendar.YEAR, y); c.set(Calendar.MONTH, m); c.set(Calendar.DAY_OF_MONTH, d)
                            selectedCal = c
                        },
                        selectedCal.get(Calendar.YEAR), selectedCal.get(Calendar.MONTH), selectedCal.get(Calendar.DAY_OF_MONTH)
                    ).show()
                }) { Text(SimpleDateFormat("MMM d, yyyy", Locale.getDefault()).format(selectedCal.time)) }

                OutlinedButton(onClick = {
                    TimePickerDialog(
                        context,
                        { _, h, min ->
                            val c = selectedCal.clone() as Calendar
                            c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, min)
                            selectedCal = c
                        },
                        selectedCal.get(Calendar.HOUR_OF_DAY), selectedCal.get(Calendar.MINUTE), false
                    ).show()
                }) { Text(SimpleDateFormat("h:mm a", Locale.getDefault()).format(selectedCal.time)) }
            }
            Spacer(Modifier.height(16.dp))

            Text("Repeat", fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold, color = InkSoft)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(RepeatMode.NONE to "Never", RepeatMode.DAILY to "Daily", RepeatMode.WEEKLY to "Weekly")
                    .forEach { (mode, label) ->
                        FilterChip(
                            selected = repeat == mode,
                            onClick = { repeat = mode },
                            label = { Text(label) }
                        )
                    }
            }
            Spacer(Modifier.height(24.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                Button(
                    onClick = { if (title.isNotBlank()) onSave(title.trim(), selectedCal.timeInMillis, repeat) },
                    colors = ButtonDefaults.buttonColors(containerColor = Teal),
                    modifier = Modifier.weight(1f)
                ) { Text("Save reminder") }
            }
        }
    }
}
