package com.daybook.reminders.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class RepeatMode { NONE, DAILY, WEEKLY }

@Entity(tableName = "reminders")
data class Reminder(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    // epoch millis, in the device's local time zone at creation
    val dateTimeMillis: Long,
    val repeat: RepeatMode = RepeatMode.NONE,
    val done: Boolean = false
)
