package com.daybook.reminders.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.daybook.reminders.CHANNEL_ID
import com.daybook.reminders.MainActivity
import com.daybook.reminders.data.ReminderDatabase
import com.daybook.reminders.data.RepeatMode
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Calendar

class AlarmReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_REMINDER_ID = "extra_reminder_id"
        const val EXTRA_TITLE = "extra_title"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val reminderId = intent.getLongExtra(EXTRA_REMINDER_ID, -1L)
        val title = intent.getStringExtra(EXTRA_TITLE) ?: "Reminder"

        showNotification(context, reminderId, title)

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                handleRepeat(context, reminderId)
            } finally {
                pendingResult.finish()
            }
        }
    }

    private fun showNotification(context: Context, reminderId: Long, title: String) {
        val activityIntent = Intent(context, MainActivity::class.java)
        val activityPendingIntent = android.app.PendingIntent.getActivity(
            context, reminderId.toInt(), activityIntent,
            android.app.PendingIntent.FLAG_UPDATE_CURRENT or android.app.PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("Reminder")
            .setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setAutoCancel(true)
            .setContentIntent(activityPendingIntent)
            .build()

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU ||
            androidx.core.content.ContextCompat.checkSelfPermission(
                context, android.Manifest.permission.POST_NOTIFICATIONS
            ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        ) {
            NotificationManagerCompat.from(context).notify(reminderId.toInt(), notification)
        }
    }

    private suspend fun handleRepeat(context: Context, reminderId: Long) {
        if (reminderId < 0) return
        val dao = ReminderDatabase.getInstance(context).reminderDao()
        val reminder = dao.getById(reminderId) ?: return

        if (reminder.repeat == RepeatMode.NONE) {
            dao.update(reminder.copy(done = true))
            return
        }

        val cal = Calendar.getInstance().apply { timeInMillis = reminder.dateTimeMillis }
        when (reminder.repeat) {
            RepeatMode.DAILY -> cal.add(Calendar.DAY_OF_YEAR, 1)
            RepeatMode.WEEKLY -> cal.add(Calendar.WEEK_OF_YEAR, 1)
            RepeatMode.NONE -> {}
        }
        val updated = reminder.copy(dateTimeMillis = cal.timeInMillis, done = false)
        dao.update(updated)
        AlarmScheduler.schedule(context, updated)
    }
}
