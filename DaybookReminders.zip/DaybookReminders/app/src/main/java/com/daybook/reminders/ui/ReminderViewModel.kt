package com.daybook.reminders.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.daybook.reminders.alarm.AlarmScheduler
import com.daybook.reminders.data.Reminder
import com.daybook.reminders.data.ReminderDatabase
import com.daybook.reminders.data.RepeatMode
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class ReminderViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = ReminderDatabase.getInstance(app).reminderDao()

    val reminders = dao.observeAll().stateIn(
        viewModelScope,
        SharingStarted.WhileSubscribed(5000),
        emptyList()
    )

    fun addReminder(title: String, dateTimeMillis: Long, repeat: RepeatMode) {
        viewModelScope.launch {
            val reminder = Reminder(title = title, dateTimeMillis = dateTimeMillis, repeat = repeat)
            val id = dao.insert(reminder)
            AlarmScheduler.schedule(getApplication(), reminder.copy(id = id))
        }
    }

    fun toggleDone(reminder: Reminder) {
        viewModelScope.launch {
            if (!reminder.done) {
                AlarmScheduler.cancel(getApplication(), reminder.id)
            }
            dao.update(reminder.copy(done = !reminder.done))
        }
    }

    fun delete(reminder: Reminder) {
        viewModelScope.launch {
            AlarmScheduler.cancel(getApplication(), reminder.id)
            dao.delete(reminder)
        }
    }
}
