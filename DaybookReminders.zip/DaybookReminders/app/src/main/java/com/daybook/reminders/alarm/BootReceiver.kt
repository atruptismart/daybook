package com.daybook.reminders.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.daybook.reminders.data.ReminderDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val pendingResult = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try {
                val dao = ReminderDatabase.getInstance(context).reminderDao()
                val now = System.currentTimeMillis()
                dao.getAllOnce()
                    .filter { !it.done && it.dateTimeMillis > now }
                    .forEach { AlarmScheduler.schedule(context, it) }
            } finally {
                pendingResult.finish()
            }
        }
    }
}
