# Daybook — a native Android reminders app

A small native Android app: add a reminder, get a real notification at that
time even if the app is closed, swiped away, or the phone was rebooted since.
Built with Kotlin, Jetpack Compose, Room, and AlarmManager.

## What you need

- [Android Studio](https://developer.android.com/studio) (free), which
  includes the Android SDK and Gradle needed to build this.
- An Android phone (or emulator) running Android 8.0 (API 26) or newer.

## How to build and install it

1. Unzip this project, then in Android Studio: **File → Open**, and select
   the `DaybookReminders` folder.
2. Let Gradle sync — the first sync downloads dependencies and can take a
   few minutes.
3. Plug your Android phone into your computer via USB, with **USB
   debugging** enabled (Settings → About phone → tap "Build number" 7
   times to unlock Developer options, then Settings → Developer options →
   USB debugging).
4. Pick your device from the device dropdown at the top of Android Studio
   and press the green **Run ▶** button. The app installs and opens on
   your phone directly.

No phone handy? Use **Run ▶** with a Pixel emulator instead to try it on
your computer first.

## Getting a standalone .apk file (to install without a cable)

**Build → Build Bundle(s) / APK(s) → Build APK(s)** in Android Studio.
When it finishes, click the "locate" link in the notification to find
`app-debug.apk`, then transfer that file to your phone (email, Drive,
USB) and tap it to install — you'll need to allow "install unknown apps"
for whichever app you send it through, since it isn't from the Play
Store.

## First launch

The app will ask for two permissions — **allow both** so reminders
actually fire:
- **Notifications** — lets it show the reminder alert.
- **Alarms & reminders** — lets Android wake the app at the exact time
  you set, even in the background (Android 12+ only; sends you to a
  system settings screen once, then returns).

## How it works

- Reminders are stored locally on the phone in a small Room (SQLite)
  database — nothing leaves the device.
- Adding a reminder schedules a real OS-level alarm (`AlarmManager`)
  that survives Doze/battery-saving mode.
- A `BOOT_COMPLETED` receiver re-schedules all upcoming alarms if the
  phone restarts, since Android clears alarms on reboot.
- Marking a repeating reminder (daily/weekly) done rolls it forward to
  its next occurrence and reschedules it automatically.

## Customizing

- Colors live at the top of `ui/ReminderScreen.kt`.
- The app icon is a vector drawable at
  `res/drawable/ic_launcher_foreground.xml` — edit the `pathData` or
  colors there to change it.
- App name is in `res/values/strings.xml`.
